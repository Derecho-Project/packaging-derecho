#pragma once

namespace mutils{
	namespace resource_pool{
		enum class resource_type {
			overdrawn,spare,preferred
				};
	}}
