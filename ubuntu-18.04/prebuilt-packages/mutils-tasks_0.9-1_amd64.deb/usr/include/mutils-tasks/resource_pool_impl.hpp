#pragma once
#include <cassert>
#include "resource_pool.hpp"
#include "resource_pool_impl_resource_pack.hpp"
#include "resource_pool_impl_state.hpp"
#include "resource_pool_impl_resource_pool.hpp"
#include "resource_pool_impl_resource.hpp"
#include "resource_pool_impl_index_owner.hpp"
#include "resource_pool_impl_locked_resource.hpp"
#include "resource_pool_impl_weak_resource.hpp"
#include "resource_pool_impl_overdrawn_resource.hpp"
#include "resource_pool_impl_spare_resource.hpp"

