#pragma once
#include <exception>
#include <string>

namespace mutils{
	
	std::string exn_typename(std::exception_ptr p);

}
