#pragma once

namespace derecho {
enum class Mode {
    ORDERED,
    UNORDERED
};
}
